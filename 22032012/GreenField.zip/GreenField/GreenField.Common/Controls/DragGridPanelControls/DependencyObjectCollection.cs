using System.Collections.ObjectModel;
using System.Windows;


namespace GreenField.Common.DragGridPanelControls
{
    public class DependencyObjectCollection : ObservableCollection<DependencyObject>
    {
    }
}