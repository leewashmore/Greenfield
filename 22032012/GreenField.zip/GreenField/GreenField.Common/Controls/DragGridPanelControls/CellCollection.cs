using System.Collections.ObjectModel;

namespace GreenField.Common.DragGridPanelControls
{
    public class CellCollection : ObservableCollection<Cell>
    {
    }
}