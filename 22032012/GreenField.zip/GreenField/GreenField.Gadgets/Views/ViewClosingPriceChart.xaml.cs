﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using GreenField.Gadgets.ViewModels;
using GreenField.Gadgets.Helpers;
using System.IO;
using GreenField.Common;

namespace GreenField.Gadgets.Views
{
    public partial class ViewClosingPriceChart : UserControl
    {
        #region Variables

        public DateTime startDate = DateTime.Today.AddYears(-1);
        public DateTime endDate = DateTime.Today;

        #endregion


        /// <summary>
        /// Constructor
        /// </summary>
        public ViewClosingPriceChart(ViewModelClosingPriceChart DataContextSource)
        {
            InitializeComponent();
            this.DataContext = DataContextSource;
            DataContextSource.closingPriceDataLoadedEvent += new DataRetrievalProgressIndicator(DataContextSource_closingPriceDataLoadedEvent);
            this.chPricing.DefaultView.ChartArea.AxisX.AxisStyles.ItemLabelStyle = this.Resources["ItemLabelStyle"] as Style;
            this.chPricing.DefaultView.ChartArea.AxisY.AxisStyles.ItemLabelStyle = this.Resources["ItemLabelStyle"] as Style;
            this.chPricing.DefaultView.ChartArea.AxisX.TicksDistance = 50;
            this.chVolume.DefaultView.ChartLegend.Visibility = Visibility.Collapsed;
        }


        void DataContextSource_closingPriceDataLoadedEvent(DataRetrievalProgressIndicatorEventArgs e)
        {
            if (e.ShowBusy)
                this.busyIndicator.IsBusy = true;
            else
                this.busyIndicator.IsBusy = false;
        }

        /// <summary>
        /// Flipping between Grid & Chart
        /// Using the method FlipItem in class Flipper.cs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTFlip_Click(object sender, RoutedEventArgs e)
        {
            UIElement elementOver = this.dgPricing.Visibility == System.Windows.Visibility.Visible ? (UIElement)this.dgPricing : (UIElement)this.chPricing;
            UIElement elementUnder = elementOver == (UIElement)this.chPricing ? (UIElement)this.dgPricing : (UIElement)this.chPricing;
            Flipper.FlipItem(elementOver, elementUnder);
        }

        private void btnBFlip_Click(object sender, RoutedEventArgs e)
        {
            UIElement elementOver = this.dgVolume.Visibility == System.Windows.Visibility.Visible ? (UIElement)this.dgVolume : (UIElement)this.chVolume;
            UIElement elementUnder = elementOver == (UIElement)this.chVolume ? (UIElement)this.dgVolume : (UIElement)this.chVolume;
            Flipper.FlipItem(elementOver, elementUnder);
        }

        /// <summary>
        /// Method to catch Click Event of Export to Excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExportExcel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog dialog = new SaveFileDialog();
                dialog.DefaultExt = "XLSX";  //Default Format for saving file
                dialog.Filter = this.GetDefaulExt();

                if (!(bool)dialog.ShowDialog())
                    return;

                Stream fileStream = dialog.OpenFile();
                this.ExportTheFile(fileStream);
                fileStream.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string GetDefaulExt()
        {
            return string.Format("{1} File (*.{0}) | *.{0}", "xlsx", "XLSX");
        }

        /// <summary>
        /// Method writing the stream of chart to an Excel File using ExportToExcelMl method.
        /// </summary>
        /// <param name="fileStream"></param>
        private void ExportTheFile(Stream fileStream)
        {
            try
            {
                //closingPriceChart.ExportToExcelML(fileStream);
                //volumeChart.ExportToExcelML(fileStream);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbFrequencyInterval_SelectionChanged(object sender, Telerik.Windows.Controls.SelectionChangedEventArgs e)
        {
            string timeInterval = cmbTime.SelectedValue.ToString();
            switch (cmbFrequencyInterval.SelectedValue.ToString())
            {
                case ("Daily"):
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "d";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        this.chPricing.DefaultView.ChartArea.AxisX.AutoRange = false;
                        this.chPricing.DefaultView.ChartArea.AxisX.Step = 5;
                        this.chPricing.DefaultView.ChartArea.AxisX.LabelStep = 2;
                        break;
                    }
                case ("Weekly"):
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "d";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        this.chPricing.DefaultView.ChartArea.AxisX.AutoRange = false;
                        this.chPricing.DefaultView.ChartArea.AxisX.Step = 7;
                        this.chPricing.DefaultView.ChartArea.AxisX.LabelStep = 2;
                        break;
                    }
                case ("Monthly"):
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "m";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        this.chPricing.DefaultView.ChartArea.AxisX.AutoRange = false;
                        this.chPricing.DefaultView.ChartArea.AxisX.Step = 1;
                        this.chPricing.DefaultView.ChartArea.AxisX.LabelStep = 2;
                        break;
                    }
                case ("Half-Yearly"):
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "m";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        this.chPricing.DefaultView.ChartArea.AxisX.AutoRange = false;
                        this.chPricing.DefaultView.ChartArea.AxisX.Step = 6;
                        this.chPricing.DefaultView.ChartArea.AxisX.LabelStep = 1;
                        break;
                    }
                case ("Yearly"):
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "Y";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        this.chPricing.DefaultView.ChartArea.AxisX.AutoRange = false;
                        this.chPricing.DefaultView.ChartArea.AxisX.Step = 1;
                        this.chPricing.DefaultView.ChartArea.AxisX.LabelStep = 2;
                        break;
                    }
                default:
                    {
                        this.chPricing.DefaultView.ChartArea.AxisX.DefaultLabelFormat = "d";
                        this.chPricing.DefaultView.ChartArea.SmartLabelsEnabled = true;
                        break;
                    }
            }
        }

        private void cmbTime_SelectionChanged(object sender, Telerik.Windows.Controls.SelectionChangedEventArgs e)
        {
            switch (cmbTime.SelectedValue.ToString())
            {
                case ("1-Month"):
                    {
                        //this.chPricing.DefaultView.ChartArea.AxisX.MinValue = Convert.ToDouble(DateTime.Today.AddMonths(-1));
                        //this.chPricing.DefaultView.ChartArea.AxisX.MaxValue = Convert.ToDouble(DateTime.Today);
                        break;
                    }
                case ("2-Months"):
                    {
                        break;
                    }
                case ("3-Months"):
                    {
                        break;
                    }
                case ("6-Months"):
                    {
                        break;
                    }
                case ("9-Months"):
                    {
                        break;
                    }
                case "1-Year":
                    {
                        break;
                    }
                case "2-Years":
                    break;
                case "3-Years":
                    break;
                case "4-Years":
                    break;
                case "5-Years":
                    break;
                case "10-Years":
                    break;

                default:
                    break;
            }
        }
    }
}
